/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miniprojectproducts.servlet;

/**
 *
 * @author Eudes
 */
import com.mycompany.miniprojectproducts.dao.ProductDAO;
import com.mycompany.miniprojectproducts.model.Product;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class ProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        if("add".equals(action)){
            String name = req.getParameter("name");
            double price = Double.parseDouble(req.getParameter("price"));
            int quantity = Integer.parseInt(req.getParameter("quantity"));
            Product p = new Product(name, price, quantity);
            ProductDAO.addProduct(p);
        }

        resp.sendRedirect("products.jsp");
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if("delete".equals(action)){
            int id = Integer.parseInt(req.getParameter("id"));
            ProductDAO.deleteProduct(id);
        }
        resp.sendRedirect("products.jsp");
    }
}

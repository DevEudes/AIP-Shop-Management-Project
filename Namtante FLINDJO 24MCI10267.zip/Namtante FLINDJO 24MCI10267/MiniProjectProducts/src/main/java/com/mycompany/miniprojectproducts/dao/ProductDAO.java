/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miniprojectproducts.dao;

/**
 *
 * @author Eudes
 */
import com.mycompany.miniprojectproducts.model.Product;
import com.mycompany.miniprojectproducts.servlet.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public static int addProduct(Product p) {
        int status = 0;
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO products(name,price,quantity) VALUES(?,?,?)");
            ps.setString(1, p.getName());
            ps.setDouble(2, p.getPrice());
            ps.setInt(3, p.getQuantity());
            status = ps.executeUpdate();
            conn.close();
        } catch (Exception e) { e.printStackTrace(); }
        return status;
    }

    public static List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM products");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setPrice(rs.getDouble("price"));
                p.setQuantity(rs.getInt("quantity"));
                products.add(p);
            }
            conn.close();
        } catch (Exception e) { e.printStackTrace(); }
        return products;
    }

    public static int deleteProduct(int id) {
        int status = 0;
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM products WHERE id=?");
            ps.setInt(1, id);
            status = ps.executeUpdate();
            conn.close();
        } catch (Exception e) { e.printStackTrace(); }
        return status;
    }
}

